<%-- 
    Document   : header
    Created on : 14 Apr 2026, 4:09:05 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<div style="text-align: center; padding: 20px; background-color: #e6f7ff; font-family: Arial, sans-serif;">
    <h2>Student Club Registration System</h2>
    <hr>
    <a href="registerClub.jsp" style="margin: 0 10px; text-decoration: none; color: #0056b3; font-weight: bold;">Registration Page</a> | 
    <a href="feeCalculator.jsp" style="margin: 0 10px; text-decoration: none; color: #0056b3; font-weight: bold;">Fee Calculator Page</a> | 
    <a href="memberDirectory.jsp" style="margin: 0 10px; text-decoration: none; color: #0056b3; font-weight: bold;">Club Member Directory</a>
    <hr>
</div>