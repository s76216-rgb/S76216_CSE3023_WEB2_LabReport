<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 4:08:29 pm
    Author     : Ikhwan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Registration Page</title>
    </head>
    <body style="margin: 0; font-family: Arial, sans-serif;">
        
        <%@ include file="header.jsp" %>
        
        <center>
            <h3>Club Registration Form</h3>
            <form action="processRegistration.jsp" method="post">
                <table cellpadding="8">
                    <tr>
                        <td>Student Name:</td>
                        <td><input type="text" name="studentName" size="30" required></td>
                    </tr>
                    <tr>
                        <td>Matric Number:</td>
                        <td><input type="text" name="matricNumber" size="30" required></td>
                    </tr>
                    <tr>
                        <td>Selected Club:</td>
                        <td>
                            <select name="selectedClub">
                                <option value="Programming Club">Programming Club</option>
                                <option value="Robotics Club">Robotics Club</option>
                                <option value="Multimedia & Design Club">Multimedia & Design Club</option>
                                <option value="Cyber Security Society">Cyber Security Society</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" value="Submit Registration">
                            <input type="reset" value="Clear Form">
                        </td>
                    </tr>
                </table>
            </form>
        </center>
        
        <%@ include file="footer.jsp" %>
        
    </body>
</html>