<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 4:11:35 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<div style="text-align: center; padding: 15px; margin-top: 30px; background-color: #e6f7ff; font-family: Arial, sans-serif; font-size: 14px;">
    <hr>
    <p>&copy; Faculty of Computer Science and Mathematics, UMT</p>
</div>