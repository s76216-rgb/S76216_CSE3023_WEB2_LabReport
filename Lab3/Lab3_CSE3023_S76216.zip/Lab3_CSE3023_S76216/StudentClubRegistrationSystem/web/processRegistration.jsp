<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 4:12:54 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Registration Output</title>
    </head>
    <body style="margin: 0; font-family: Arial, sans-serif;">
        
        <%@ include file="header.jsp" %>
        
        <center>
            <h3 style="color: green;">Registration Successful!</h3>
            
            <%
                String name = request.getParameter("studentName");
                String matric = request.getParameter("matricNumber");
                String club = request.getParameter("selectedClub");
                
                // Retrieve the shared list from the server
                ArrayList<String> sharedList = (ArrayList<String>) application.getAttribute("globalMemberList");
                
                // If it doesn't exist yet, create it and add the default 5 members
                if (sharedList == null) {
                    sharedList = new ArrayList<String>();
                    sharedList.add("Ahmad Faizal");
                    sharedList.add("Siti Aminah");
                    sharedList.add("Jason Lee");
                    sharedList.add("Priya Sharma");
                    sharedList.add("Nurul Izzah");
                }
                
                // Add the new user to the list and save it back to the server
                if (name != null && !name.trim().isEmpty()) {
                    sharedList.add(name);
                    application.setAttribute("globalMemberList", sharedList);
                }
            %>
            
            <fieldset style="width: 400px; text-align: left; background-color: #f9f9f9;">
                <legend><strong>Submitted Information</strong></legend>
                <p><strong>Student Name:</strong> <%= name %></p>
                <p><strong>Matric Number:</strong> <%= matric %></p>
                <p><strong>Assigned Club:</strong> <%= club %></p>
            </fieldset>
        </center>
        
        <%@ include file="footer.jsp" %>
        
    </body>
</html>