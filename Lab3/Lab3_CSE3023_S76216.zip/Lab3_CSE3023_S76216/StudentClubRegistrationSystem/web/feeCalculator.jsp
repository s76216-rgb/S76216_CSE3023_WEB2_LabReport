<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 4:13:18 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Fee Calculator Page</title>
    </head>
    <body style="margin: 0; font-family: Arial, sans-serif;">
        
        <%@ include file="header.jsp" %>
        
        <center>
            <h3>Membership Fee Calculator</h3>
            <p><em>Note: Each activity costs RM10.00</em></p>
            
            <form method="post">
                Number of activities joined: 
                <input type="number" name="activities" min="1" required>
                <input type="submit" value="Calculate Fee">
            </form>
            
            <br>
            
            <%
                // Mathematical Logic
                String strActivities = request.getParameter("activities");
                
                if (strActivities != null) {
                    int numActivities = Integer.parseInt(strActivities);
                    double totalFee = numActivities * 10.00;
                    
                    // Formatting to 2 decimal places
                    String formattedFee = String.format("%.2f", totalFee);
                    
                    out.println("<h4 style='color: blue;'>Total Amount to Pay: RM " + formattedFee + "</h4>");
                }
            %>
        </center>
        
        <%@ include file="footer.jsp" %>
        
    </body>
</html>
