<%-- 
    Document   : memberDirectory
    Created on : 14 Apr 2026, 4:13:48 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Club Member Directory</title>
    </head>
    <body style="margin: 0; font-family: Arial, sans-serif;">
        
        <%@ include file="header.jsp" %>
        
        <center>
            <h3>Current Committee Members</h3>
            
            <%
                // Retrieve the shared list from the server
                ArrayList<String> memberList = (ArrayList<String>) application.getAttribute("globalMemberList");
                
                // If no one has registered yet, just show the default list
                if (memberList == null) {
                    memberList = new ArrayList<String>();
                    memberList.add("Ahmad Faizal");
                    memberList.add("Siti Aminah");
                    memberList.add("Jason Lee");
                    memberList.add("Priya Sharma");
                    memberList.add("Nurul Izzah");
                    application.setAttribute("globalMemberList", memberList);
                }
            %>
            
            <table border="1" cellpadding="8" cellspacing="0" style="width: 50%; text-align: center;">
                <tr style="background-color: #0056b3; color: white;">
                    <th>No.</th>
                    <th>Committee Member Name</th>
                </tr>
                <%
                    for (int i = 0; i < memberList.size(); i++) {
                %>
                <tr>
                    <td><%= (i + 1) %></td>
                    <td><%= memberList.get(i) %></td>
                </tr>
                <%
                    }
                %>
            </table>
        </center>
        
        <%@ include file="footer.jsp" %>
        
    </body>
</html>