<%-- 
    Document   : mainPage
    Created on : 14 Apr 2026, 3:50:52 pm
    Author     : Ikhwan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>mainPage</title>
    </head>
    <body style="font-family: serif;">
        
        <%@ include file="headerPage.jsp" %>
        
        <div style="padding: 10px 20px;">
            <h2>Using JSP Include directive</h2>
            <p style="color: red;">
                Java Server Page (JSP) is a technology for controlling the content<br>
                or appearance of Web pages through the use of servlets, small<br>
                programs that are specified in the Web page and run on the Web server<br>
                to modify the Web page before it is sent to the user who requested it.
            </p>
        </div>
        
        <%@ include file="footerPage.jsp" %>
        
    </body>
</html>