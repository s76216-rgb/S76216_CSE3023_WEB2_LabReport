<%-- 
    Document   : populateArray
    Created on : 14 Apr 2026, 3:05:29 pm
    Author     : Ikhwan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Read Java array and populate it into HTML table.</h2>
        
        <%
            // Step 2: Write a Java Scriptlet and store the information into an array
            // Note: The output image shows the numbers without commas, so they are stored as such.
            String[][] salesData = {
                {"Salesman 1", "2500", "2100", "2200"},
                {"Salesman 2", "2000", "1900", "2400"},
                {"Salesman 3", "1800", "2200", "2450"}
            };
        %>
        
        <table border="1" cellpadding="5" cellspacing="0">
            <tr bgcolor="#e6c25e">
                <th>Salesman</th>
                <th>Jan</th>
                <th>Feb</th>
                <th>Mac</th>
            </tr>
            <% 
                for (int i = 0; i < salesData.length; i++) { 
            %>
            <tr align="center">
                <td align="left"><%= salesData[i][0] %></td>
                <td><%= salesData[i][1] %></td>
                <td><%= salesData[i][2] %></td>
                <td><%= salesData[i][3] %></td>
            </tr>
            <% 
                } 
            %>
        </table>
        
        <br>
        &copy;2026-Ikhwan
    </body>
</html>
