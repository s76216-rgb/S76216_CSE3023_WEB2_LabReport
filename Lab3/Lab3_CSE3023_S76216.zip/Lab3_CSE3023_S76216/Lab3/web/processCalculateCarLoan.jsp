<%-- 
    Document   : processCalculateCarLoan
    Created on : 14 Apr 2026, 3:23:55 pm
    Author     : Ikhwan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Loan Result</title>
    </head>
    <body>
        <h2>Perform Car Loan Calculation</h2>
        
        <%
            // Retrieve parameters from calculateCarLoan.html
            // Note: The field names must match the 'name' attributes from your HTML form
            String strAmount = request.getParameter("amount");
            String strPeriod = request.getParameter("period");
            
            double amount = 0.0;
            int period = 0;
            double totalLoan = 0.0;
            
            if (strAmount != null && strPeriod != null) {
                amount = Double.parseDouble(strAmount);
                period = Integer.parseInt(strPeriod);
                
                // Based on 50000 over 7 years = 65750, the interest rate is 4.5% (0.045)
                // Formula: Total = Principal + (Principal * Rate * Time)
                double interest = amount * 0.045 * period;
                totalLoan = amount + interest;
            }
        %>
        
        <fieldset style="border: 1px solid #ccc; padding: 15px; margin-bottom: 20px;">
            <h3 style="color: blue;">Details of car loan:</h3>
            
            <p>Loan Request : <%= amount %></p>
            <p>Period of payment : <%= period %></p>
            <p>Total Loan (+ interest) : <%= totalLoan %></p>
        </fieldset>
        
        &copy;2026-Ikhwan
    </body>
</html>