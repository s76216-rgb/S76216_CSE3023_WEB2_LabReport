<%-- 
    Document   : headerPage
    Created on : 14 Apr 2026, 3:55:45 pm
    Author     : Ikhwan
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<div style="background-color: #ffe4c4; padding: 20px; text-align: center;">
    <h2>ABC Sdn Bhd</h2>
</div>