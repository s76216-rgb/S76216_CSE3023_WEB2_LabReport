<%-- 
    Document   : footerPage
    Created on : 14 Apr 2026, 3:56:29 pm
    Author     : Ikhwan
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<div style="background-color: #ffe4c4; padding: 15px; text-align: center;">
    &copy;2026-Ikhwan
</div>