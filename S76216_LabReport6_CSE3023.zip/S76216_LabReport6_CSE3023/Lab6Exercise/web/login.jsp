<%-- 
    Document   : login
    Created on : 12 May 2026, 3:17:33 pm
    Author     : Ikhwan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>System Login</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        color: #333;
        margin: 40px;
    }

    h2 {
        color: #0056b3;
        border-bottom: 2px solid #ccc;
        padding-bottom: 10px;
        width: fit-content;
    }

    /* Style the table used for form alignment */
    table {
        background-color: #fff;
        border-collapse: collapse;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        border-radius: 8px;
        overflow: hidden;
        margin-top: 20px;
    }

    td {
        padding: 12px 15px;
    }

    /* Style the input fields */
    input[type="text"], 
    input[type="password"] {
        width: 200px;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    /* Style the submit buttons */
    input[type="submit"] {
        background-color: #0056b3;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
        width: 100%;
    }

    input[type="submit"]:hover {
        background-color: #004494;
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #0056b3;
        text-decoration: none;
        font-weight: bold;
    }

    a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
    <h2>System Login</h2>
    
    <%-- Display error message if redirected from doLogin.jsp --%>
    <% if (request.getParameter("msg") != null) { %>
        <p style='color:red;'><strong><%= request.getParameter("msg") %></strong></p>
    <% } %>

    <form action="doLogin.jsp" method="POST">
        <table>
            <tr><td>Username:</td><td><input type="text" name="username" required></td></tr>
            <tr><td>Password:</td><td><input type="password" name="password" required></td></tr>
            <tr><td colspan="2"><input type="submit" value="Login"></td></tr>
        </table>
    </form>
    <br>
    <a href="insertUser.html">Register a new account</a>
</body>
</html>
