<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 3:19:00 pm
    Author     : Ikhwan
--%>

<%@page import="java.sql.*" contentType="text/html" pageEncoding="UTF-8"%>
<%
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        // UPDATED: Using Lab6Exercise database
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Lab6Exercise", "root", "admin");
        
        String sql = "SELECT * FROM userprofile WHERE username = ? AND password = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, request.getParameter("username"));
        pstmt.setString(2, request.getParameter("password"));
        
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            // Validation succeeds: Set session attributes and redirect to main.jsp
            session.setAttribute("username", rs.getString("username"));
            session.setAttribute("firstname", rs.getString("firstname"));
            session.setAttribute("lastname", rs.getString("lastname"));
            response.sendRedirect("main.jsp");
        } else {
            // Validation fails: Redirect back to login.jsp with the exact requested message
            response.sendRedirect("login.jsp?msg=Invalid username or password..!");
        }
        
        conn.close();
    } catch (Exception e) { 
        out.println("Error: " + e.getMessage()); 
    }
%>
