<%-- 
    Document   : processUser
    Created on : 12 May 2026, 3:03:56 pm
    Author     : Ikhwan
--%>

<%@page import="java.sql.*" contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <body>
        <%
            try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/Lab6Exercise", "root", "admin");
            
            String sql = "INSERT INTO userprofile (username, password, firstname, lastname) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("username"));
            pstmt.setString(2, request.getParameter("password"));
            pstmt.setString(3, request.getParameter("firstname"));
            pstmt.setString(4, request.getParameter("lastname"));
            
            if (pstmt.executeUpdate() > 0) {
                out.println("<h3 style='color:green;'>Registration successful!</h3>");
                out.println("<a href='login.jsp'>Click here to login</a>");
            } else {
                out.println("<h3 style='color:red;'>Registration failed.</h3>");
                out.println("<a href='insertUser.html'>Try again</a>");
            }
            conn.close();
        } catch (Exception e) { 
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>"); 
        }
    %>
    </body>
</html>
