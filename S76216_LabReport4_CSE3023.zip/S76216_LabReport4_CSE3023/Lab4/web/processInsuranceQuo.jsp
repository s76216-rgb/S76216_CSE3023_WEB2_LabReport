<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%
    String icno = request.getParameter("icno");
    String name = request.getParameter("name");
    String coverage = request.getParameter("coverage");
    String ncdStr = request.getParameter("ncd");
    
    double price = 0;
    double ncd = 0;
    try {
        price = Double.parseDouble(request.getParameter("price"));
        ncd = Double.parseDouble(ncdStr);
    } catch (Exception e) {
        price = 0;
        ncd = 0;
    }

    double rate = 0;
    String coverageDisplay = "";
    if ("comprehensive".equals(coverage)) {
        rate = 0.05; // 5%
        coverageDisplay = "Comprehensive";
    } else {
        rate = 0.03; // 3%
        coverageDisplay = "Third Party";
    }

    double insurance = price * rate;
    double discount = insurance * ncd;
    double afterNCD = insurance - discount;
    double sst = afterNCD * 0.08;
    double finalAmount = afterNCD + sst;
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Insurance Quotation Result</h1>
        <div class="card">
            <div class="result-group">
                <label>IC No:</label> <p><%= icno %></p>
            </div>
            <div class="result-group">
                <label>Name:</label> <p><%= name %></p>
            </div>
            <div class="result-group">
                <label>Market Price (RM):</label> <p><%= String.format("%.2f", price) %></p>
            </div>
            <div class="result-group">
                <label>Coverage Type:</label> <p><%= coverageDisplay %></p>
            </div>
            <div class="result-group">
                <label>NCD:</label> <p><%= (int)(ncd * 100) %>%</p>
            </div>
            <hr>
            <div class="result-group">
                <label>Base Insurance:</label> <p>RM <%= String.format("%.2f", insurance) %></p>
            </div>
            <div class="result-group">
                <label>NCD Discount:</label> <p>RM <%= String.format("%.2f", discount) %></p>
            </div>
            <div class="result-group">
                <label>After NCD:</label> <p>RM <%= String.format("%.2f", afterNCD) %></p>
            </div>
            <div class="result-group">
                <label>SST (8%):</label> <p>RM <%= String.format("%.2f", sst) %></p>
            </div>
            <div class="result-group" style="font-size: 1.2rem; margin-top: 15px;">
                <label>Final Insurance Amount:</label> 
                <p><strong>RM <%= String.format("%.2f", finalAmount) %></strong></p>
            </div>
            <div class="button-group">
                <button class="btn btn-submit" onclick="window.history.back()">Back</button>
            </div>
        </div>
    </div>
</body>
</html>