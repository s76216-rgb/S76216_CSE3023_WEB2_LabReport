<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    String name = request.getParameter("uname");
    String email = request.getParameter("email");
    String nationality = request.getParameter("nationality");
    String background = request.getParameter("background");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Forwarded Info</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Using jsp:forward to display user info</h1>
        <div class="card">
            <h2 class="form-title">Forwarded Info</h2>
            <div class="result-group">
                <label>Name:</label> <p><%= name %></p>
            </div>
            <div class="result-group">
                <label>Email:</label> <p><%= email %></p>
            </div>
            <div class="result-group">
                <label>Nationality:</label> <p><%= nationality %></p>
            </div>
            <div class="result-group">
                <label>Background:</label> <p><%= background %></p>
            </div>
        </div>
    </div>
</body>
</html>