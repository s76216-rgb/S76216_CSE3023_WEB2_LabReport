<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%
    // Fixed price
    final double price = 10.0;

    // Retrieve form data
    String cust_no = request.getParameter("customerCode");
    String cust_type = request.getParameter("customerType");

    int quantity = 0;
    try {
        quantity = Integer.parseInt(request.getParameter("quantity"));
    } catch (Exception e) {
        quantity = 0;
    }

    // Business logic
    double total = 0;
    String message = "";

    if (cust_type != null && cust_type.equals("1") && quantity > 100) {
        message = "You're entitled to 10% discount";
        total = quantity * price * 0.9;

    } else if (cust_type != null && cust_type.equals("2") && quantity > 100) {
        message = "You're entitled to 25% discount";
        total = quantity * price * 0.75;

    } else {
        message = "You're not entitled to any discount";
        total = quantity * price;
    }

    // Display customer type
    String custTypeDisplay = (cust_type != null && cust_type.equals("1")) ? 
        "Normal Customer" : "Privilege Customer";
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Discount Result</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Specific tweaks to match the manual's stacked layout perfectly */
        .summary-item {
            margin-bottom: 15px;
        }
        .summary-item label {
            display: block;
            font-size: 0.9rem;
            color: #333;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .summary-item p {
            margin: 0;
            font-size: 0.9rem;
            color: #555;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Customer Discount Result</h1>
        
        <div class="card">
            <h2 class="form-title">Transaction Summary</h2>
            
            <div class="summary-item">
                <label>Customer Code:</label>
                <p><%= cust_no != null ? cust_no : "" %></p>
            </div>

            <div class="summary-item">
                <label>Quantity:</label>
                <p><%= quantity %></p>
            </div>

            <div class="summary-item">
                <label>Customer Type:</label>
                <p><%= custTypeDisplay %></p>
            </div>

            <div class="summary-item">
                <label>Status:</label>
                <p><%= message %></p>
            </div>

            <div class="summary-item">
                <label>Total Amount:</label>
                <p>RM <%= String.format("%.2f", total) %></p>
            </div>

            <div class="button-group" style="margin-top: 20px;">
                <button class="btn btn-submit" style="padding: 5px 15px; font-size: 0.9rem;" onclick="window.history.back()">Back</button>
            </div>

        </div>
    </div>

</body>
</html>


