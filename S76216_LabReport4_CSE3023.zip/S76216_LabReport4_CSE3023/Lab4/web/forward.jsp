<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Using JSP Standard Action (Forward)</title>
</head>
<body>
    <h1>Using jsp:forward to display user information</h1>
    <jsp:forward page="forwardInfo.jsp">
        <jsp:param name="uname" value="Muhammad Ikhwan Bin Mohd Fairuz Yasmin" />
        <jsp:param name="email" value="s76216@ocean.umt.edu.my" />
        <jsp:param name="nationality" value="Malaysia" />
        <jsp:param name="background" value="Student" />
    </jsp:forward>
</body>
</html>