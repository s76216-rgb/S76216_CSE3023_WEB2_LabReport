<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Insurance Quotation</h1>
        <div class="card">
            <h2 class="form-title">Insurance Calculation</h2>
            <form action="processInsuranceQuo.jsp" method="POST">
                <div class="form-group">
                    <label for="icno">IC No.</label>
                    <input type="text" id="icno" name="icno" placeholder="e.g., 888888-08-8888" required>
                </div>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" placeholder="Enter name" required>
                </div>
                <div class="form-group">
                    <label for="price">Market Price (RM)</label>
                    <input type="number" id="price" name="price" placeholder="Value" required>
                </div>
                <div class="form-group">
                    <label for="coverage">Coverage Type</label>
                    <select id="coverage" name="coverage">
                        <option value="comprehensive">Comprehensive</option>
                        <option value="thirdparty">Third Party</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="ncd">No Claims Discount (NCD)</label>
                    <select id="ncd" name="ncd">
                        <option value="0.10">10%</option>
                        <option value="0.25">25%</option>
                        <option value="0.55">55%</option>
                    </select>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn btn-submit">Submit</button>
                    <button type="reset" class="btn btn-cancel">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>