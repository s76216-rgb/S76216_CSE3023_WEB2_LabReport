<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BMI Calculator</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .navbar { background: #6f42c1; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .navbar a { color: white; text-decoration: none; font-weight: bold; margin-right: 20px; }
        .navbar a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Information</a>
        </div>