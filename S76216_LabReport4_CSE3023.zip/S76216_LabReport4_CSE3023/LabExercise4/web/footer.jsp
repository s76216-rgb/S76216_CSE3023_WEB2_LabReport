<div style="text-align: center; margin-top: 30px; color: #777; font-size: 0.9em;">
            <hr>
            <p>&copy; 2026 Faculty of Computer Science and Mathematics, UMT.</p>
        </div>
    </div>
</body>
</html>