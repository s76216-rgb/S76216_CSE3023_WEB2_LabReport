<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ include file="header.jsp" %>

<div class="card">
    <h2 class="form-title">Your BMI Result</h2>
    
    <%
        double rawBmi = 0;
        try {
            rawBmi = Double.parseDouble(request.getParameter("bmiValue"));
        } catch (Exception e) {
            rawBmi = 0;
        }
    %>

    <div class="result-group">
        <label>Calculated BMI:</label>
        <p><strong><%= String.format("%.2f", rawBmi) %></strong></p>
    </div>
    <div class="result-group">
        <label>Health Category:</label>
        <p><strong><%= request.getParameter("bmiCategory") %></strong></p>
    </div>
    
    <div class="button-group">
        <a href="bmiCalculator.jsp" class="btn btn-submit" style="text-decoration:none;">Recalculate</a>
    </div>
</div>

<%@ include file="footer.jsp" %>