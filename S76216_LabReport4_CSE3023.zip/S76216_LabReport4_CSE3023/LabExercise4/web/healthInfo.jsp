<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<div class="card">
    <h2 class="form-title">BMI Health Categories</h2>
    <p>Body Mass Index (BMI) is a simple index of weight-for-height that is commonly used to classify health risks.</p>
    
    <%
        ArrayList<String> categories = new ArrayList<String>();
        categories.add("BMI < 18.5 : Underweight");
        categories.add("18.5 <= BMI <= 25 : Normal");
        categories.add("BMI > 25 : Overweight");
    %>

    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
        <tr style="background-color: #6f42c1; color: white;">
            <th style="padding: 10px; border: 1px solid #ccc;">BMI Range & Health Category</th>
        </tr>
        <%
            for (int i = 0; i < categories.size(); i++) {
        %>
        <tr>
            <td style="padding: 10px; border: 1px solid #ccc; text-align: center;">
                <%= categories.get(i) %>
            </td>
        </tr>
        <%
            }
        %>
    </table>
</div>

<%@ include file="footer.jsp" %>