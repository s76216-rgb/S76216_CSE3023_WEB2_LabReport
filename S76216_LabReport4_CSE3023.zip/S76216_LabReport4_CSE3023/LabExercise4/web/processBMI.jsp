<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");

    double weight = 0;
    double height = 0;
    double bmi = 0;
    String category = "Invalid Data";

    try {
        weight = Double.parseDouble(weightStr);
        height = Double.parseDouble(heightStr);

        if (height > 0) {
            bmi = weight / (height * height);

            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi <= 25) {
                category = "Normal";
            } else {
                category = "Overweight";
            }
        } else {
            category = "Error: Height cannot be zero";
        }
    } catch (Exception e) {
        bmi = 0;
        category = "Error: Input must be numeric";
    }
%>
<jsp:forward page="resultBMI.jsp">
    <jsp:param name="bmiValue" value="<%= bmi %>" />
    <jsp:param name="bmiCategory" value="<%= category %>" />
</jsp:forward>