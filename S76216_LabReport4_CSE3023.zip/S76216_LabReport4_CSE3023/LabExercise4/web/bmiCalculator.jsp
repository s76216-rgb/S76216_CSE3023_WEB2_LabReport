<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ include file="header.jsp" %>

<div class="card">
    <h2 class="form-title">Calculate Your BMI</h2>
    <form action="processBMI.jsp" method="POST">
        <div class="form-group">
            <label for="weight">Weight (kg):</label>
            <input type="number" step="0.1" id="weight" name="weight" required>
        </div>
        <div class="form-group">
            <label for="height">Height (m):</label>
            <input type="number" step="0.01" id="height" name="height" required>
        </div>
        <div class="button-group">
            <button type="submit" class="btn btn-submit">Calculate BMI</button>
        </div>
    </form>
</div>

<%@ include file="footer.jsp" %>