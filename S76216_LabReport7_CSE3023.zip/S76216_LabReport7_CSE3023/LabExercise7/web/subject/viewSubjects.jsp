<%@page import="java.util.List"%>
<%@page import="com.lab.bean.SubjectBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>My Registered Subjects</title></head>
<body>
    <h2>Subject List</h2>
    <a href="<%= request.getContextPath() %>/SubjectServlet?action=new">Register New Subject</a> | 
    <a href="<%= request.getContextPath() %>/dashboard.jsp">Back to Dashboard</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Subject Code</th>
            <th>Subject Name</th>
            <th>Actions</th>
        </tr>
        <% 
            List<SubjectBean> subjects = (List<SubjectBean>) request.getAttribute("listSubjects");
            if (subjects != null && !subjects.isEmpty()) {
                for (SubjectBean sub : subjects) {
        %>
        <tr>
            <td><%= sub.getId() %></td>
            <td><%= sub.getSubject_code() %></td>
            <td><%= sub.getSubject_name() %></td>
            <td>
                <a href="<%= request.getContextPath() %>/SubjectServlet?action=edit&id=<%= sub.getId() %>">Edit</a> | 
                <a href="<%= request.getContextPath() %>/SubjectServlet?action=delete&id=<%= sub.getId() %>" 
                   onclick="return confirm('Are you sure you want to delete this subject?');">Delete</a>
            </td>
        </tr>
        <% 
                }
            } else {
        %>
        <tr>
            <td colspan="4">No subjects registered yet.</td>
        </tr>
        <% } %>
    </table>
</body>
</html>