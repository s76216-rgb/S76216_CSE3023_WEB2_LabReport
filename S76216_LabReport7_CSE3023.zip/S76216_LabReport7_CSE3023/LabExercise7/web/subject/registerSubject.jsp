<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Register Subject</title></head>
<body>
    <h2>Register New Subject</h2>
    <form action="<%= request.getContextPath() %>/SubjectServlet" method="post">
        <input type="hidden" name="action" value="add">
        <label>Subject Code:</label>
        <input type="text" name="subject_code" required><br><br>
        <label>Subject Name:</label>
        <input type="text" name="subject_name" required><br><br>
        <input type="submit" value="Register">
        <a href="<%= request.getContextPath() %>/SubjectServlet?action=view">Cancel</a>
    </form>
</body>
</html>