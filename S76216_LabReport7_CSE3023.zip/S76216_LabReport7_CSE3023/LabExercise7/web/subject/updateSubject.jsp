<%@page import="com.lab.bean.SubjectBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Update Subject</title></head>
<body>
    <h2>Edit Subject</h2>
    <% SubjectBean subject = (SubjectBean) request.getAttribute("subject"); %>
    <form action="<%= request.getContextPath() %>/SubjectServlet" method="post">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<%= subject.getId() %>">
        <label>Subject Code:</label>
        <input type="text" name="subject_code" value="<%= subject.getSubject_code() %>" required><br><br>
        <label>Subject Name:</label>
        <input type="text" name="subject_name" value="<%= subject.getSubject_name() %>" required><br><br>
        <input type="submit" value="Update">
        <a href="<%= request.getContextPath() %>/SubjectServlet?action=view">Cancel</a>
    </form>
</body>
</html>>