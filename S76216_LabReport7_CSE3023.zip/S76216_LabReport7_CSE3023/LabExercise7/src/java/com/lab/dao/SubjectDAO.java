package com.lab.dao;

import com.lab.bean.SubjectBean;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAO {
    protected Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/lab7_db", "root", "admin");
    }

    public void insertSubject(SubjectBean subject) {
        String sql = "INSERT INTO registered_subjects (matric_no, subject_code, subject_name) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, subject.getMatric_no());
            stmt.setString(2, subject.getSubject_code());
            stmt.setString(3, subject.getSubject_name());
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<SubjectBean> selectAllSubjectsByMatric(String matric_no) {
        List<SubjectBean> subjects = new ArrayList<>();
        String sql = "SELECT * FROM registered_subjects WHERE matric_no = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, matric_no);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String subject_code = rs.getString("subject_code");
                String subject_name = rs.getString("subject_name");
                subjects.add(new SubjectBean(id, matric_no, subject_code, subject_name));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return subjects;
    }

    public SubjectBean selectSubjectById(int id) {
        SubjectBean subject = null;
        String sql = "SELECT * FROM registered_subjects WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String matric_no = rs.getString("matric_no");
                String subject_code = rs.getString("subject_code");
                String subject_name = rs.getString("subject_name");
                subject = new SubjectBean(id, matric_no, subject_code, subject_name);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return subject;
    }

    public void updateSubject(SubjectBean subject) {
        String sql = "UPDATE registered_subjects SET subject_code = ?, subject_name = ? WHERE id = ? AND matric_no = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, subject.getSubject_code());
            stmt.setString(2, subject.getSubject_name());
            stmt.setInt(3, subject.getId());
            stmt.setString(4, subject.getMatric_no()); 
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void deleteSubject(int id, String matric_no) {
        String sql = "DELETE FROM registered_subjects WHERE id = ? AND matric_no = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setString(2, matric_no); 
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}