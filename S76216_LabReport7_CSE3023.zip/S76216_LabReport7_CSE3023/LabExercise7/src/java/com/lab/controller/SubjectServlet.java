package com.lab.controller;

import com.lab.bean.SubjectBean;
import com.lab.bean.StudentBean;
import com.lab.dao.SubjectDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SubjectServlet extends HttpServlet {
    private SubjectDAO subjectDAO;

    public void init() {
        subjectDAO = new SubjectDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.html");
            return;
        }
        
        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");
        String matricNo = loggedUser.getMatricNo();

        String action = request.getParameter("action");
        if (action == null) { action = "view"; }

        switch (action) {
            case "new": showNewForm(request, response); break;
            case "add": insertSubject(request, response, matricNo); break;
            case "edit": showEditForm(request, response); break;
            case "update": updateSubject(request, response, matricNo); break;
            case "delete": deleteSubject(request, response, matricNo); break;
            case "view":
            default: listSubjects(request, response, matricNo); break;
        }
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/subject/registerSubject.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        SubjectBean existingSubject = subjectDAO.selectSubjectById(id);
        request.setAttribute("subject", existingSubject);
        request.getRequestDispatcher("/subject/updateSubject.jsp").forward(request, response);
    }

    private void insertSubject(HttpServletRequest request, HttpServletResponse response, String matricNo) throws IOException {
        String code = request.getParameter("subject_code");
        String name = request.getParameter("subject_name");
        SubjectBean newSubject = new SubjectBean(matricNo, code, name);
        subjectDAO.insertSubject(newSubject);
        response.sendRedirect("SubjectServlet?action=view");
    }

    private void updateSubject(HttpServletRequest request, HttpServletResponse response, String matricNo) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String code = request.getParameter("subject_code");
        String name = request.getParameter("subject_name");
        SubjectBean subject = new SubjectBean(id, matricNo, code, name);
        subjectDAO.updateSubject(subject);
        response.sendRedirect("SubjectServlet?action=view");
    }

    private void deleteSubject(HttpServletRequest request, HttpServletResponse response, String matricNo) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        subjectDAO.deleteSubject(id, matricNo);
        response.sendRedirect("SubjectServlet?action=view");
    }

    private void listSubjects(HttpServletRequest request, HttpServletResponse response, String matricNo) throws ServletException, IOException {
        List<SubjectBean> listSubjects = subjectDAO.selectAllSubjectsByMatric(matricNo);
        request.setAttribute("listSubjects", listSubjects);
        request.getRequestDispatcher("/subject/viewSubjects.jsp").forward(request, response);
    }
}