<%-- 
    Document   : jstl_test
    Created on : 29 Apr 2026, 2:56:29 pm
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSTL Core Tags</title>
</head>
<body>
    <h2>JSTL Conditional Test</h2>
    <c:set var="score" value="85" />
    <p>Student Score: <c:out value="${score}" /> marks.</p>
    
    <c:if test="${score >= 50}">
        <p style="color: green;"><strong>Status: Pass! Congratulations.</strong></p>
    </c:if>
    <c:if test="${score < 50}">
        <p style="color: red;"><strong>Status: Fail. Please try again.</strong></p>
    </c:if>
</body>
</html>