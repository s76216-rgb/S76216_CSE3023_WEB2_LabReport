package com.lab.controller;

import com.lab.bean.Employee;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PayrollServlet")
public class PayrollServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Create a list to hold employee objects
        List<Employee> employeeList = new ArrayList<>();

        // Populating 5 different Employee objects
        Employee e1 = new Employee();
        e1.setEmpId("EMP-01"); e1.setName("Ikhwan"); e1.setDepartment("Engineering"); e1.setBasicSalary(3500.00);

        Employee e2 = new Employee();
        e2.setEmpId("EMP-02"); e2.setName("Dini"); e2.setDepartment("Human Resources"); e2.setBasicSalary(2800.00);

        Employee e3 = new Employee();
        e3.setEmpId("EMP-03"); e3.setName("Ammar"); e3.setDepartment("Marketing"); e3.setBasicSalary(3200.00);

        Employee e4 = new Employee();
        e4.setEmpId("EMP-04"); e4.setName("Sasuke"); e4.setDepartment("IT Support"); e4.setBasicSalary(2500.00);

        Employee e5 = new Employee();
        e5.setEmpId("EMP-05"); e5.setName("Paviruddin"); e5.setDepartment("Operations"); e5.setBasicSalary(4000.00);

        // Add employees to the list
        employeeList.add(e1);
        employeeList.add(e2);
        employeeList.add(e3);
        employeeList.add(e4);
        employeeList.add(e5);

        // Share data with JSP
        request.setAttribute("employeeList", employeeList);

        // Forward to View
        RequestDispatcher rd = request.getRequestDispatcher("payroll_view.jsp");
        rd.forward(request, response);
    }
}